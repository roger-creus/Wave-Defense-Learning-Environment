from setuptools import setup 

setup(name='wave_defense', version='0.0.1', install_requires=['gym', 'pygame', 'numpy'], author = "Roger Creus", description="A Reinforcement Learning environment inspired from wave defense games")